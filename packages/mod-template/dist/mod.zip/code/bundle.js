return (() => {
  var Mod=(()=>{var l=Object.defineProperty;var s=(e,a)=>{for(var d in a)l(e,d,{get:a[d],enumerable:!0})};var n={};s(n,{default:()=>r});var M=GDAPI,{Mod:t,ModManager:x,Callbacks:c,loadExtension:f,parseModManifest:g,loadModFile:m}=GDAPI;var o=class extends t{preEvent(){console.log("My mod is working!")}},r=o;return n;})();
  return Mod.default;
})();
