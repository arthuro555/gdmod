// This is not the main file but it will also get loaded
console.log("Other Got Loaded :)");
console.log("[OTHER]: " + MyAwesomeMod.message)
